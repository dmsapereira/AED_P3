package bikeManagement.exceptions;

/**
 * <code>Exception</code> for when some parameter is invalid
 */
public class InvalidDataException extends RuntimeException {
}
