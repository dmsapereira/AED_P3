package bikeManagement.exceptions.user;

/**
 * <code>Exception</code> for when there's an attempt at using an occupied <code>User</code>
 */
public class BusyUserException extends RuntimeException {
}
