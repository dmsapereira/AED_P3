package bikeManagement.exceptions.user;

/**
 * <code>Exception</code> for when there's an attempt at listing a new <code>User</code>'s <code>PickUp</code>s
 */
public class NewUserException extends RuntimeException {
}
